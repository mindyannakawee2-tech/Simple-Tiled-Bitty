return {
    name = "main",
    tilewidth = 32,
    tileheight = 32,
    tilecount = 448,
    columns = 16,
    image = "tiled/tileset.png",
    imagewidth = 512,
    imageheight = 992
}