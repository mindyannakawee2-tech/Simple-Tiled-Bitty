<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="tileset" tilewidth="32" tileheight="32" tilecount="496" columns="16">
 <image source="tileset.png" width="512" height="992"/>
</tileset>
