local Animation = {}

function Animation.new(animations, defaultState, frameTime)
    local self = {}

    self.animations = animations or {}
    self.currentState = defaultState or "down"
    self.currentFrame = 1
    self.timer = 0
    self.frameTime = frameTime or 0.15
    self.playing = true

    function self:setState(state)
        if self.currentState ~= state then
            self.currentState = state
            self.currentFrame = 1
            self.timer = 0
        end
    end

    function self:update(delta)
        if not self.playing then
            return
        end

        local frames = self.animations[self.currentState]
        if not frames or #frames <= 1 then
            return
        end

        self.timer = self.timer + delta
        if self.timer >= self.frameTime then
            self.timer = self.timer - self.frameTime
            self.currentFrame = self.currentFrame + 1

            if self.currentFrame > #frames then
                self.currentFrame = 1
            end
        end
    end

    function self:getFrame()
        local frames = self.animations[self.currentState]
        if not frames then
            return nil
        end
        return frames[self.currentFrame]
    end

    function self:reset()
        self.currentFrame = 1
        self.timer = 0
    end

    return self
end

return Animation