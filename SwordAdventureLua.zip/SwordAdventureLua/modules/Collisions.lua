local Collision = {}

Collision.tileSize = 32

-- จุดเริ่มต้นของ collision shape ใน world
Collision.originX = 352
Collision.originY = 64

-- shape ของก้อนหิน
Collision.grid = {
    {0,1,1,1,1,0},
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
    {1,1,1,1,1,1},
    {0,1,1,1,1,0},
}

function Collision.isBlockedTile(localTx, localTy)
    if localTy < 1 or localTy > #Collision.grid then
        return false
    end

    local row = Collision.grid[localTy]
    if localTx < 1 or localTx > #row then
        return false
    end

    return row[localTx] == 1
end

function Collision.worldToLocalTile(px, py)
    local localX = px - Collision.originX
    local localY = py - Collision.originY

    local tx = math.floor(localX / Collision.tileSize) + 1
    local ty = math.floor(localY / Collision.tileSize) + 1

    return tx, ty
end

function Collision.rectHitsBlockedTile(x, y, w, h)
    local leftTile   = math.floor((x - Collision.originX) / Collision.tileSize) + 1
    local rightTile  = math.floor((x + w - 1 - Collision.originX) / Collision.tileSize) + 1
    local topTile    = math.floor((y - Collision.originY) / Collision.tileSize) + 1
    local bottomTile = math.floor((y + h - 1 - Collision.originY) / Collision.tileSize) + 1

    for ty = topTile, bottomTile do
        for tx = leftTile, rightTile do
            if Collision.isBlockedTile(tx, ty) then
                return true, tx, ty
            end
        end
    end

    return false, nil, nil
end

return Collision