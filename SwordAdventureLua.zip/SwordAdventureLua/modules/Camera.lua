local Camera = {}

function Camera.new(viewW, viewH, mapW, mapH)
    local self = {}

    self.x = 0
    self.y = 0
    self.viewW = viewW or 480
    self.viewH = viewH or 270
    self.mapW = mapW or viewW or 480
    self.mapH = mapH or viewH or 270
    self.smooth = 8

    function self:update(targetX, targetY, delta)
        local targetCamX = targetX - self.viewW / 2
        local targetCamY = targetY - self.viewH / 2

        self.x = self.x + (targetCamX - self.x) * self.smooth * delta
        self.y = self.y + (targetCamY - self.y) * self.smooth * delta

        if self.x < 0 then self.x = 0 end
        if self.y < 0 then self.y = 0 end
        if self.x > self.mapW - self.viewW then self.x = self.mapW - self.viewW end
        if self.y > self.mapH - self.viewH then self.y = self.mapH - self.viewH end
    end

    function self:applyX(x)
        return x - self.x
    end

    function self:applyY(y)
        return y - self.y
    end

    return self
end

return Camera