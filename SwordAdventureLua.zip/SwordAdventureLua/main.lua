keys = require "modules/KeyCodes"
Animation = require "modules/Animation"
Camera = require "modules/Camera"
Tiled = require "modules/Tiled"

local player = nil
local camera = nil
local map = nil
local debugToggle = false
local lastHitObject = nil

local SCREEN_W = 480
local SCREEN_H = 322.5

local MAP_DRAW_X = 0
local MAP_DRAW_Y = 0

function setup()
    map = Tiled.load("maps/StartingMap", MAP_DRAW_X, MAP_DRAW_Y)

    playerIMG = {}

    playerIMG.down = {
        Resources.load("img/sprites/player/down1.png"),
        Resources.load("img/sprites/player/down2.png"),
        Resources.load("img/sprites/player/down3.png"),
        Resources.load("img/sprites/player/down2.png"),
    }

    playerIMG.up = {
        Resources.load("img/sprites/player/up1.png"),
        Resources.load("img/sprites/player/up2.png"),
        Resources.load("img/sprites/player/up3.png"),
        Resources.load("img/sprites/player/up2.png"),
    }

    playerIMG.left = {
        Resources.load("img/sprites/player/left1.png"),
        Resources.load("img/sprites/player/left2.png"),
        Resources.load("img/sprites/player/left3.png"),
        Resources.load("img/sprites/player/left2.png"),
    }

    playerIMG.right = {
        Resources.load("img/sprites/player/right1.png"),
        Resources.load("img/sprites/player/right2.png"),
        Resources.load("img/sprites/player/right3.png"),
        Resources.load("img/sprites/player/right2.png"),
    }

    player = {}
    player.x = 100
    player.y = 100
    player.w = 32
    player.h = 64
    player.walkspeed = 100
    player.sprintspeed = 275
    player.speed = player.walkspeed
    player.moving = false
    player.lastDir = "down"

    player.animSpeedWalk = 0.25
    player.animSpeedRun = 0.12
    player.anim = Animation.new(playerIMG, "down", player.animSpeedWalk)

    camera = Camera.new(SCREEN_W, SCREEN_H, map.pixelWidth, map.pixelHeight)

    local spawn = map:getObject("SpawnPoints", "PlayerSpawn")
    if spawn then
        player.x = spawn.x
        player.y = spawn.y - player.h
    end
end

function getFeetBox(px, py)
    local fw = 16
    local fh = 12
    local fx = px + math.floor((player.w - fw) / 2)
    local fy = py + player.h - fh
    return fx, fy, fw, fh
end

function feetCollides(nextX, nextY)
    local fx, fy, fw, fh = getFeetBox(nextX, nextY)
    return map:checkCollisionRect(fx, fy, fw, fh)
end

function clampToMapByFeet(nextX, nextY)
    local fx, fy, fw, fh = getFeetBox(nextX, nextY)

    if fx < 0 then
        nextX = nextX + (0 - fx)
    end

    if fy < 0 then
        nextY = nextY + (0 - fy)
    end

    if fx + fw > map.pixelWidth then
        nextX = nextX - ((fx + fw) - map.pixelWidth)
    end

    if fy + fh > map.pixelHeight then
        nextY = nextY - ((fy + fh) - map.pixelHeight)
    end

    return nextX, nextY
end

function tryMove(moveX, moveY, delta)
    local nextX = player.x + moveX * player.speed * delta
    local nextY = player.y + moveY * player.speed * delta

    nextX, nextY = clampToMapByFeet(nextX, nextY)

    lastHitObject = nil

    local hitX, objX = feetCollides(nextX, player.y)
    if not hitX then
        player.x = nextX
    else
        lastHitObject = objX
    end

    local hitY, objY = feetCollides(player.x, nextY)
    if not hitY then
        player.y = nextY
    else
        lastHitObject = objY
    end
end

function update(delta)
    if not player or not map then
        text("Map or player not loaded", 10, 10)
        return
    end

    local moveX = 0
    local moveY = 0

    player.speed = player.walkspeed
    player.moving = false
    player.anim.frameTime = player.animSpeedWalk

    if key(keys.LShift) then
        player.speed = player.sprintspeed
        player.anim.frameTime = player.animSpeedRun
    end

    if key(keys.A) then moveX = moveX - 1 end
    if key(keys.D) then moveX = moveX + 1 end
    if key(keys.W) then moveY = moveY - 1 end
    if key(keys.S) then moveY = moveY + 1 end

    if keyp(keys.Q) then
        debugToggle = not debugToggle
    end

    if moveX ~= 0 or moveY ~= 0 then
        player.moving = true

        if moveY < 0 then
            player.lastDir = "up"
        elseif moveY > 0 then
            player.lastDir = "down"
        elseif moveX < 0 then
            player.lastDir = "left"
        elseif moveX > 0 then
            player.lastDir = "right"
        end

        player.anim:setState(player.lastDir)
        tryMove(moveX, moveY, delta)
    end

    if player.moving then
        player.anim.playing = true
        player.anim:update(delta)
    else
        player.anim.playing = false
        player.anim:setState(player.lastDir)
        player.anim.currentFrame = 2
    end

    camera:update(player.x + player.w / 2, player.y + player.h / 2, delta)

    -- back layers
    map:drawLayers({
        "Tile Layer 1",
        "Tile Layer 2"
    }, camera)

    -- player
    tex(
        player.anim:getFrame(),
        camera:applyX(player.x),
        camera:applyY(player.y),
        player.w,
        player.h
    )

    -- front layers
    map:drawLayers({
        "Tile Layer 3",
        "Tile Layer 4"
    }, camera)

    if debugToggle then
        local fx, fy, fw, fh = getFeetBox(player.x, player.y)

        text("Player: " .. math.floor(player.x) .. "," .. math.floor(player.y), 10, 10)
        text("Camera: " .. math.floor(camera.x) .. "," .. math.floor(camera.y), 10, 25)
        text("Map: " .. map.pixelWidth .. "," .. map.pixelHeight, 10, 40)
        text("Feet: " .. math.floor(fx) .. "," .. math.floor(fy) .. "," .. fw .. "," .. fh, 10, 55)

        if lastHitObject then
            text(
                "Hit Obj: id=" .. tostring(lastHitObject.id or 0) ..
                " name=" .. tostring(lastHitObject.name or "") ..
                " x=" .. math.floor(lastHitObject.x or 0) ..
                " y=" .. math.floor(lastHitObject.y or 0) ..
                " w=" .. math.floor(lastHitObject.w or 0) ..
                " h=" .. math.floor(lastHitObject.h or 0),
                10, 70
            )
        end

        rect(
            camera:applyX(fx),
            camera:applyY(fy),
            camera:applyX(fx + fw),
            camera:applyY(fy + fh)
        )

        local collisionLayer = map.ObjectLayer["CollisionLayer"]
        if collisionLayer then
            for i = 1, #collisionLayer.objects do
                local obj = collisionLayer.objects[i]
                rect(
                    camera:applyX(obj.x),
                    camera:applyY(obj.y),
                    camera:applyX(obj.x + obj.w),
                    camera:applyY(obj.y + obj.h)
                )
            end
        end
    end
end